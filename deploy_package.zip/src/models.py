from datetime import datetime
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB Connection
mongo_client = MongoClient(os.getenv('MONGO_URI'))
db = mongo_client.get_database('aisyncy')

# Constants
CHAT_STATUS = {
    'UNREAD': 'unread',
    'IN_PROGRESS': 'in_progress',
    'RESOLVED': 'resolved'
}

PAYMENT_STATUS = {
    'PENDING': 'pending',
    'PAID': 'paid',
    'FAILED': 'failed'
}

RECHARGE_STATUS = {
    'PENDING': 'pending',
    'SUCCESS': 'success',
    'FAILED': 'failed'
}

class UserProfile:
    @staticmethod
    def create_or_update(phone_number, data):
        """Create or update user profile"""
        return db.user_profiles.update_one(
            {'phone_number': phone_number},
            {'$set': {
                **data,
                'updated_at': datetime.utcnow()
            }},
            upsert=True
        )

    @staticmethod
    def get(phone_number):
        """Get user profile"""
        return db.user_profiles.find_one({'phone_number': phone_number})

class ChatAssignment:
    @staticmethod
    def assign(phone_number, agent_id, agent_name):
        """Assign chat to an agent"""
        return db.chat_assignments.update_one(
            {'phone_number': phone_number},
            {'$set': {
                'agent_id': agent_id,
                'agent_name': agent_name,
                'status': CHAT_STATUS['IN_PROGRESS'],
                'assigned_at': datetime.utcnow()
            }},
            upsert=True
        )

    @staticmethod
    def update_status(phone_number, status):
        """Update chat status"""
        return db.chat_assignments.update_one(
            {'phone_number': phone_number},
            {'$set': {
                'status': status,
                'updated_at': datetime.utcnow()
            }}
        )

    @staticmethod
    def get_assignment(phone_number):
        """Get chat assignment"""
        return db.chat_assignments.find_one({'phone_number': phone_number})

class RechargeRequest:
    @staticmethod
    def create(phone_number, operator, plan, amount):
        """Create new recharge request"""
        return db.recharge_requests.insert_one({
            'phone_number': phone_number,
            'operator': operator,
            'plan': plan,
            'amount': amount,
            'payment_status': PAYMENT_STATUS['PENDING'],
            'recharge_status': RECHARGE_STATUS['PENDING'],
            'created_at': datetime.utcnow()
        })

    @staticmethod
    def update_status(phone_number, payment_status=None, recharge_status=None):
        """Update recharge request status"""
        update_data = {'updated_at': datetime.utcnow()}
        if payment_status:
            update_data['payment_status'] = payment_status
        if recharge_status:
            update_data['recharge_status'] = recharge_status

        return db.recharge_requests.update_one(
            {'phone_number': phone_number},
            {'$set': update_data}
        )

    @staticmethod
    def get_requests(status=None):
        """Get recharge requests with optional status filter"""
        query = {}
        if status:
            query['recharge_status'] = status
        return list(db.recharge_requests.find(query).sort('created_at', -1))

class RechargeHistory:
    @staticmethod
    def add(phone_number, operator, plan, amount, status):
        """Add recharge history entry"""
        return db.recharge_history.insert_one({
            'phone_number': phone_number,
            'operator': operator,
            'plan': plan,
            'amount': amount,
            'status': status,
            'timestamp': datetime.utcnow()
        })

    @staticmethod
    def get_history(phone_number):
        """Get recharge history for a user"""
        return list(db.recharge_history.find({'phone_number': phone_number})
                   .sort('timestamp', -1))

class AutoRechargeSettings:
    @staticmethod
    def create_or_update(phone_number, settings):
        """Create or update auto recharge settings"""
        return db.auto_recharge_settings.update_one(
            {'phone_number': phone_number},
            {'$set': {
                **settings,
                'updated_at': datetime.utcnow()
            }},
            upsert=True
        )

    @staticmethod
    def get_settings(phone_number):
        """Get auto recharge settings"""
        return db.auto_recharge_settings.find_one({'phone_number': phone_number})

class SupportAgent:
    @staticmethod
    def create(agent_id, name, email):
        """Create new support agent"""
        return db.support_agents.insert_one({
            'agent_id': agent_id,
            'name': name,
            'email': email,
            'created_at': datetime.utcnow()
        })

    @staticmethod
    def get_all():
        """Get all support agents"""
        return list(db.support_agents.find())

    @staticmethod
    def get(agent_id):
        """Get support agent by ID"""
        return db.support_agents.find_one({'agent_id': agent_id})

class MessageTemplate:
    @staticmethod
    def create(**kwargs):
        """Create new message template"""
        return db.message_templates.insert_one(kwargs)

    @staticmethod
    def get_all():
        """Get all message templates"""
        return list(db.message_templates.find())

    @staticmethod
    def get(template_id):
        """Get message template by ID"""
        return db.message_templates.find_one({'_id': template_id})

    @staticmethod
    def format_message(template, **kwargs):
        """Format message based on template type"""
        if template['message_type'] == 'text':
            return template['content']
        elif template['message_type'] == 'button':
            return {
                'type': 'interactive',
                'interactive': {
                    'type': 'button',
                    'body': {'text': template['content']},
                    'action': {
                        'buttons': [
                            {'type': 'reply', 'reply': {'id': f'btn_{i}', 'title': opt}}
                            for i, opt in enumerate(template['button_options'])
                        ]
                    }
                }
            }
        elif template['message_type'] == 'list':
            return {
                'type': 'interactive',
                'interactive': {
                    'type': 'list',
                    'body': {'text': template['content']},
                    'action': {
                        'button': template['list_title'],
                        'sections': [{
                            'title': template['list_title'],
                            'rows': [
                                {'id': f'opt_{i}', 'title': opt}
                                for i, opt in enumerate(template['list_options'])
                            ]
                        }]
                    }
                }
            }
        elif template['message_type'] == 'contact':
            return {
                'type': 'contacts',
                'contacts': [{
                    'name': {'formatted_name': template['contact_name']},
                    'phones': [{'phone': template['contact_phone']}]
                }]
            }
        elif template['message_type'] == 'image':
            return {
                'type': 'image',
                'image': {'link': template['image_url']},
                'caption': template.get('content', '')
            }
        return template['content'] 