import os

# Configuration variables
SECRET_KEY = os.getenv('SECRET_KEY', 'supersecretkey')
MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/aisyncy')
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'password')
WHATSAPP_PHONE_NUMBER_ID = os.getenv('WHATSAPP_PHONE_NUMBER_ID', '')
WHATSAPP_ACCESS_TOKEN = os.getenv('WHATSAPP_ACCESS_TOKEN', '')

# Logging configuration
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
