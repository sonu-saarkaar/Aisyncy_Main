import time
from datetime import datetime, timedelta
from pymongo import MongoClient
import logging

logger = logging.getLogger(__name__)

class RechargeManager:
    def __init__(self, db):
        self.db = db
        self.cleanup_interval = 24 * 60 * 60  # 24 hours in seconds

    def save_recharge_request(self, request_data):
        """Save recharge request to MongoDB"""
        try:
            request_data['created_at'] = datetime.fromtimestamp(request_data['created_at'])
            if 'updated_at' in request_data:
                request_data['updated_at'] = datetime.fromtimestamp(request_data['updated_at'])
            
            result = self.db.recharge_requests.insert_one(request_data)
            logger.info(f"Saved recharge request: {result.inserted_id}")
            return str(result.inserted_id)
        except Exception as e:
            logger.error(f"Error saving recharge request: {str(e)}")
            return None

    def update_recharge_request(self, phone_number, **kwargs):
        """Update existing recharge request"""
        try:
            kwargs['updated_at'] = datetime.utcnow()
            result = self.db.recharge_requests.update_one(
                {'phone_number': phone_number, 'status': {'$ne': 'completed'}},
                {'$set': kwargs}
            )
            logger.info(f"Updated recharge request for {phone_number}: {kwargs}")
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error updating recharge request: {str(e)}")
            return False

    def save_recharge_history(self, request_data):
        """Save completed recharge to history"""
        try:
            history_data = {
                'phone_number': request_data['phone_number'],
                'operator': request_data['operator'],
                'plan_details': request_data['plan_details'],
                'payment_details': request_data['payment_details'],
                'transaction_id': request_data['payment_details'].get('transaction_id'),
                'completed_at': datetime.utcnow()
            }
            
            result = self.db.recharge_history.insert_one(history_data)
            logger.info(f"Saved recharge history: {result.inserted_id}")
            return str(result.inserted_id)
        except Exception as e:
            logger.error(f"Error saving recharge history: {str(e)}")
            return None

    def cleanup_old_requests(self):
        """Clean up requests older than 24 hours"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=24)
            
            # Find completed requests to move to history
            completed_requests = self.db.recharge_requests.find({
                'status': 'payment_completed',
                'created_at': {'$lt': cutoff_time}
            })
            
            # Move completed requests to history
            for request in completed_requests:
                self.save_recharge_history(request)
            
            # Delete old requests
            result = self.db.recharge_requests.delete_many({
                'created_at': {'$lt': cutoff_time}
            })
            
            logger.info(f"Cleaned up {result.deleted_count} old recharge requests")
            return result.deleted_count
        except Exception as e:
            logger.error(f"Error cleaning up old requests: {str(e)}")
            return 0

    def get_user_history(self, phone_number, limit=10):
        """Get recharge history for a user"""
        try:
            history = list(self.db.recharge_history
                .find({'phone_number': phone_number})
                .sort('completed_at', -1)
                .limit(limit))
            return history
        except Exception as e:
            logger.error(f"Error fetching user history: {str(e)}")
            return []

    def get_active_requests(self):
        """Get all active recharge requests"""
        try:
            return list(self.db.recharge_requests
                .find({'status': {'$ne': 'completed'}})
                .sort('created_at', -1))
        except Exception as e:
            logger.error(f"Error fetching active requests: {str(e)}")
            return [] 