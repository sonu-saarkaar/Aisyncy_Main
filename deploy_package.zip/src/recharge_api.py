import requests
import json
import logging
from datetime import datetime
import uuid
from config import RECHARGE_API_KEY

logger = logging.getLogger(__name__)

class RechargeAPI:
    def __init__(self):
        self.user_id = "17103"
        self.token = "19118df8d0bbebabca967d0f4b941e23"
        self.base_url = "https://api.roundpay.net/API/TransactionAPI"
        
    def _make_request(self, endpoint, method="GET", params=None):
        """Make API request with error handling"""
        try:
            # Add common parameters
            if params is None:
                params = {}
            
            params.update({
                'UserID': self.user_id,
                'Token': self.token,
                'Format': '1',
                'isReal': '0',
                'routeType': '3'
            })
            
            url = f"{self.base_url}"
            
            if method == "GET":
                response = requests.get(url, params=params)
            else:
                response = requests.post(url, json=params)
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def initiate_recharge(self, phone_number, operator, amount, plan_id=None, location=None):
        """Initiate mobile recharge"""
        # Generate unique reference number
        api_request_id = f"AISYNCY{uuid.uuid4().hex[:8].upper()}"
        
        # Default location if not provided (Lucknow coordinates)
        if not location:
            location = {'longitude': '80.9462', 'latitude': '26.8467'}
            
        # Map operator names to SPKey codes
        operator_codes = {
            'VI': 'VODA',
            'VODAFONE': 'VODA',
            'JIO': 'JIO',
            'AIRTEL': 'AIRTEL',
            'BSNL': 'BSNL'
        }
        
        sp_key = operator_codes.get(operator.upper(), operator.upper())
        
        params = {
            'Account': phone_number,
            'Amount': str(amount),
            'SPKey': sp_key,
            'APIRequestID': api_request_id,
            'GEOCode': f"{location['longitude']},{location['latitude']}",
            'CustomerNumber': phone_number,
            'Pincode': '226001'  # Default pincode, can be made dynamic
        }
        
        result = self._make_request("recharge/initiate", params=params)
        
        if result.get('success'):
            return {
                'success': True,
                'transaction_id': api_request_id,
                'message': 'Recharge initiated successfully',
                'api_response': result
            }
        else:
            return {
                'success': False,
                'error': result.get('error', 'Unknown error'),
                'api_response': result
            }
    
    def check_status(self, transaction_id):
        """Check recharge status"""
        params = {
            'APIRequestID': transaction_id
        }
        return self._make_request("recharge/status", params=params)
    
    def get_operator_plans(self, operator):
        """Get available plans for operator"""
        # This would need to be implemented based on Roundpay's plan API
        # For now, returning a demo response
        return {
            'success': True,
            'plans': [
                {
                    'plan_id': '1',
                    'amount': 149,
                    'validity': '28 days',
                    'description': 'Unlimited Calls + 2GB Data/Day'
                }
            ]
        }
    
    def verify_payment(self, payment_details):
        """Verify payment before recharge"""
        # This would need to be implemented based on Roundpay's payment verification API
        # For now, returning a demo response
        return {
            'success': True,
            'verified': True,
            'payment_id': f"PAY_{int(datetime.utcnow().timestamp())}"
        }

class DemoRechargeAPI(RechargeAPI):
    """Demo implementation for testing"""
    def __init__(self):
        super().__init__()
        self.transactions = {}
    
    def initiate_recharge(self, phone_number, operator, amount, plan_id=None, location=None):
        """Demo recharge initiation"""
        transaction_id = f"TXN_{int(datetime.utcnow().timestamp())}"
        
        self.transactions[transaction_id] = {
            'phone_number': phone_number,
            'operator': operator,
            'amount': amount,
            'plan_id': plan_id,
            'status': 'pending',
            'created_at': datetime.utcnow().isoformat()
        }
        
        return {
            'success': True,
            'transaction_id': transaction_id,
            'message': 'Recharge initiated successfully'
        }
    
    def check_status(self, transaction_id):
        """Demo status check"""
        if transaction_id in self.transactions:
            # Simulate success after a delay
            transaction = self.transactions[transaction_id]
            created_at = datetime.fromisoformat(transaction['created_at'])
            now = datetime.utcnow()
            
            if (now - created_at).seconds > 5:
                transaction['status'] = 'success'
            
            return {
                'success': True,
                'status': transaction['status'],
                'details': transaction
            }
        
        return {
            'success': False,
            'error': 'Transaction not found'
        }
    
    def verify_payment(self, payment_details):
        """Demo payment verification"""
        # Always return success for demo
        return {
            'success': True,
            'verified': True,
            'payment_id': f"PAY_{int(datetime.utcnow().timestamp())}"
        }

# Initialize the appropriate API client
try:
    if RECHARGE_API_KEY:
        recharge_api = RechargeAPI()
    else:
        logger.warning("No API key found, using demo implementation")
        recharge_api = DemoRechargeAPI()
except Exception as e:
    logger.error(f"Error initializing recharge API: {str(e)}")
    recharge_api = DemoRechargeAPI() 