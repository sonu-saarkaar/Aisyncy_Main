from flask import Flask, request, jsonify
import os
from chatflow.ChatFlowController_new import RechargeController
from config import WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID, MONGO_URI
import requests
import json
import logging
from datetime import datetime
from .recharge_manager import RechargeManager
import time
import threading
from pymongo import MongoClient
import socketio

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
recharge_controller = RechargeController()

# Initialize MongoDB connection
client = MongoClient(MONGO_URI)
db = client.get_default_database()

# Initialize RechargeManager with MongoDB connection
recharge_manager = RechargeManager(db)

# WhatsApp API endpoint
WHATSAPP_API_URL = f"https://graph.facebook.com/v17.0/{WHATSAPP_PHONE_NUMBER_ID}/messages"

# Initialize Socket.IO
sio = socketio.Server(async_mode='threading', cors_allowed_origins='*')
app.wsgi_app = socketio.WSGIApp(sio, app.wsgi_app)

@sio.on('connect')
def handle_connect(sid, environ):
    logger.info(f"Client connected: {sid}")

@sio.on('disconnect')
def handle_disconnect(sid):
    logger.info(f"Client disconnected: {sid}")

def emit_recharge_update(data):
    """Emit recharge update to all connected clients"""
    try:
        sio.emit('recharge_update', data)
        logger.info(f"Emitted recharge update: {data}")
    except Exception as e:
        logger.error(f"Error emitting recharge update: {str(e)}")

def handle_recharge_webhook(data):
    """Process incoming webhook data and store in MongoDB"""
    try:
        phone_number = data.get('phone_number')
        if not phone_number:
            return {'success': False, 'error': 'Missing phone number'}

        # Get current request data
        request_data = recharge_manager.get_active_request(phone_number)
        
        # Update request data
        request_data.update({
            'whatsapp_number': phone_number,
            'recharge_number': data.get('current_number', phone_number),
            'operator': data.get('operator'),
            'plan_details': data.get('plan_details'),
            'payment_details': data.get('payment_details'),
            'status': data.get('status', 'pending'),
            'updated_at': datetime.utcnow()
        })
        
        # Save to MongoDB
        recharge_manager.update_recharge_request(phone_number, **request_data)
        
        # Emit real-time update
        emit_recharge_update({
            'type': 'recharge_update',
            'data': request_data
        })
        
        return {'success': True}
        
    except Exception as e:
        logger.error(f"Error handling recharge webhook: {str(e)}")
        return {'success': False, 'error': str(e)}

@app.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verify the webhook for WhatsApp"""
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    logger.debug(f"Webhook verification request - Mode: {mode}, Token: {token}")
    
    if mode and token:
        if mode == 'subscribe' and token == '12345':  # Updated to match the token being used
            logger.info("Webhook verified successfully")
            return challenge, 200
        else:
            logger.warning("Webhook verification failed - Invalid token")
            return 'Forbidden', 403
    return 'Bad Request', 400

@app.route('/webhook', methods=['POST'])
def webhook():
    """Handle incoming webhooks from WhatsApp"""
    try:
        # Log raw request data for debugging
        logger.info("📥 Received webhook POST request")
        logger.info(f"Headers: {dict(request.headers)}")
        
        body = request.get_data()
        logger.info(f"Raw body: {body.decode()}")

        if not request.is_json:
            logger.warning("❌ Request is not JSON format")
            return jsonify({"error": "Content type must be application/json"}), 400

        data = request.get_json()
        logger.info(f"📝 Webhook data: {json.dumps(data, indent=2)}")
        
        # Check if this is a WhatsApp Business API message
        if data.get('object') == 'whatsapp_business_account':
            logger.info("✓ Received WhatsApp Business API message")
            
            # Process WhatsApp message
            for entry in data.get('entry', []):
                for change in entry.get('changes', []):
                    value = change.get('value', {})
                    
                    # Extract messages if they exist
                    if value.get('messages'):
                        for message in value['messages']:
                            from_number = message.get('from')
                            message_type = message.get('type', 'unknown')
                            
                            if message_type == 'text':
                                message_body = message.get('text', {}).get('body', '')
                            else:
                                message_body = f"[{message_type} message]"
                                
                            message_id = message.get('id', '')
                            
                            logger.info(f"📱 Message details - From: {from_number}, Type: {message_type}, Body: {message_body}, ID: {message_id}")
                            
                            # Store the incoming message
                            try:
                                db.messages.insert_one({
                                    'phone_number': from_number,
                                    'message': message_body,
                                    'direction': 'incoming',
                                    'timestamp': datetime.utcnow(),
                                    'message_id': message_id,
                                    'message_type': message_type
                                })
                                logger.info(f"✓ Message stored in database")
                            except Exception as e:
                                logger.error(f"❌ Failed to store message: {str(e)}")
                            
                            # Process the message with recharge controller
                            try:
                                # Handle recharge logic here
                                result = handle_recharge_webhook({
                                    'phone_number': from_number,
                                    'message': message_body
                                })
                                logger.info(f"Recharge processing result: {result}")
                            except Exception as e:
                                logger.error(f"❌ Error processing recharge: {str(e)}")
                            
                            # Send an acknowledgment to WhatsApp
                            return jsonify({"status": "success"})
            
            # If we didn't find any messages, just acknowledge
            logger.info("No messages found in the webhook data, but acknowledged")
            return jsonify({"status": "success"})
        
        # Otherwise process as a custom webhook
        result = handle_recharge_webhook(data)
        
        if not result['success']:
            logger.error(f"❌ Failed to process webhook: {result.get('error')}")
            return jsonify({'error': result['error']}), 400
            
        return jsonify({'success': True})
                
    except Exception as e:
        logger.error(f"❌ Error in webhook: {str(e)}", exc_info=True)
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/webhook_test', methods=['GET'])
def webhook_test():
    """Test endpoint to verify webhook functionality"""
    try:
        # Check if WhatsApp credentials are configured
        credentials_status = {
            "whatsapp_phone_number_id": bool(WHATSAPP_PHONE_NUMBER_ID),
            "whatsapp_access_token": bool(WHATSAPP_ACCESS_TOKEN),
            "webhook_url": f"{request.url_root}webhook"
        }
        
        # Log diagnostic information
        logger.info(f"WhatsApp webhook test - Credentials status: {json.dumps(credentials_status)}")
        
        return jsonify({
            "status": "success",
            "message": "Webhook test endpoint is working",
            "credentials_status": credentials_status,
            "environment": {
                "host": request.host,
                "url_root": request.url_root
            }
        })
    except Exception as e:
        logger.error(f"Error in webhook test: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Add cleanup task
def cleanup_old_requests():
    """Periodic task to clean up old recharge requests"""
    while True:
        try:
            recharge_manager.cleanup_old_requests()
        except Exception as e:
            logger.error(f"Error in cleanup task: {str(e)}")
        time.sleep(3600)  # Run every hour

# Start cleanup task in a background thread
cleanup_thread = threading.Thread(target=cleanup_old_requests, daemon=True)
cleanup_thread.start()

if __name__ == '__main__':
    logger.info("Starting WhatsApp webhook server...")
    sio.run(app, host='0.0.0.0', port=8080, debug=False, use_reloader=False) 