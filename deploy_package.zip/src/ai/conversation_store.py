"""
Conversation history storage for Aisyncy Recharge

This module manages user conversation history to provide context for AI responses.
"""

import logging
from datetime import datetime, timedelta
from pymongo import MongoClient
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Try to import configuration from root module
try:
    from config import MONGO_URI, MONGO_DB
except ImportError:
    # Fallback to environment variables if config import fails
    import os
    logger.warning("Could not import MongoDB config, using environment variables")
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/aisyncy_recharge')
    MONGO_DB = os.environ.get('MONGO_DB', 'aisyncy_recharge')

class ConversationStore:
    """Store and retrieve conversation history for users"""
    
    def __init__(self, db=None):
        """Initialize with optional MongoDB database"""
        self.db = db
        self.in_memory_store = {}  # Fallback to in-memory storage if no DB
        
        if not self.db:
            try:
                client = MongoClient(MONGO_URI)
                self.db = client[MONGO_DB]
                logger.info("ConversationStore connected to MongoDB")
            except Exception as e:
                logger.error(f"Failed to connect to MongoDB: {str(e)}")
                logger.warning("Using in-memory conversation storage instead")
    
    def add_message(self, phone_number, role, content):
        """
        Add a message to the user's conversation history
        
        Args:
            phone_number: User's phone number as identifier
            role: Message role ('user' or 'assistant')
            content: Message content
        """
        try:
            # Sanitize phone number (remove non-digit characters)
            phone_number = ''.join(filter(str.isdigit, phone_number))
            
            # Create message document
            message = {
                "role": role,
                "content": content,
                "timestamp": datetime.utcnow()
            }
            
            # Store in MongoDB if available
            if self.db:
                self.db.conversation_history.update_one(
                    {"phone_number": phone_number},
                    {"$push": {"messages": message}},
                    upsert=True
                )
                
                # Keep conversation history to max 50 messages
                self.db.conversation_history.update_one(
                    {"phone_number": phone_number, "messages.50": {"$exists": True}},
                    {"$pop": {"messages": -1}}  # Remove the oldest message
                )
            else:
                # Use in-memory storage
                if phone_number not in self.in_memory_store:
                    self.in_memory_store[phone_number] = []
                
                self.in_memory_store[phone_number].append(message)
                
                # Keep only the last 50 messages
                if len(self.in_memory_store[phone_number]) > 50:
                    self.in_memory_store[phone_number].pop(0)
            
            logger.debug(f"Added message for {phone_number}: {role[:1]} - {content[:30]}...")
            return True
            
        except Exception as e:
            logger.error(f"Error adding message to conversation history: {str(e)}")
            return False
    
    def get_history(self, phone_number, limit=10):
        """
        Get conversation history for a user
        
        Args:
            phone_number: User's phone number as identifier
            limit: Maximum number of messages to retrieve (default: 10)
            
        Returns:
            List of messages in the format expected by OpenAI API
        """
        try:
            # Sanitize phone number (remove non-digit characters)
            phone_number = ''.join(filter(str.isdigit, phone_number))
            
            messages = []
            
            # Get from MongoDB if available
            if self.db:
                result = self.db.conversation_history.find_one({"phone_number": phone_number})
                if result and "messages" in result:
                    # Convert to OpenAI format and get the most recent 'limit' messages
                    for msg in result["messages"][-limit:]:
                        messages.append({
                            "role": msg["role"],
                            "content": msg["content"]
                        })
            else:
                # Use in-memory storage
                if phone_number in self.in_memory_store:
                    for msg in self.in_memory_store[phone_number][-limit:]:
                        messages.append({
                            "role": msg["role"],
                            "content": msg["content"]
                        })
            
            return messages
            
        except Exception as e:
            logger.error(f"Error retrieving conversation history: {str(e)}")
            return []
    
    def clear_history(self, phone_number):
        """Clear conversation history for a user"""
        try:
            # Sanitize phone number (remove non-digit characters)
            phone_number = ''.join(filter(str.isdigit, phone_number))
            
            # Clear from MongoDB if available
            if self.db:
                self.db.conversation_history.delete_one({"phone_number": phone_number})
            
            # Clear from in-memory storage
            if phone_number in self.in_memory_store:
                del self.in_memory_store[phone_number]
            
            logger.info(f"Cleared conversation history for {phone_number}")
            return True
            
        except Exception as e:
            logger.error(f"Error clearing conversation history: {str(e)}")
            return False


# Create a singleton instance
conversation_store = ConversationStore() 