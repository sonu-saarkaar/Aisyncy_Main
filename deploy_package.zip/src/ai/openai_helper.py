"""
OpenAI Integration for Aisyncy Recharge

This module provides wrapper functions to interact with OpenAI's GPT models
to enhance user interactions with more natural language responses.
"""

import os
import logging
import json
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Try to import configuration from root module
try:
    from config import OPENAI_API_KEY, OPENAI_MODEL, USE_OPENAI
except ImportError:
    # Fallback to environment variables if config import fails
    logger.warning("Could not import OpenAI config, using environment variables")
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
    OPENAI_MODEL = os.environ.get('OPENAI_MODEL', 'gpt-3.5-turbo')
    USE_OPENAI = OPENAI_API_KEY is not None and len(OPENAI_API_KEY) > 0

class OpenAIHelper:
    """Helper class to interact with OpenAI API"""
    
    def __init__(self, api_key=None, model=None):
        """Initialize with API key and model"""
        self.api_key = api_key or OPENAI_API_KEY
        self.model = model or OPENAI_MODEL
        self.enabled = self.api_key is not None and len(self.api_key) > 0
        
        if not self.enabled:
            logger.warning("OpenAI integration disabled - missing API key")
        else:
            logger.info(f"OpenAI integration enabled with model: {self.model}")
    
    def generate_response(self, user_query, context=None, user_history=None, max_tokens=300):
        """Generate a response based on user query and context"""
        if not self.enabled:
            logger.warning("OpenAI API call attempted but integration is disabled")
            return None
            
        try:
            # Prepare messages
            messages = []
            
            # System message with instructions
            system_message = {
                "role": "system", 
                "content": (
                    "You are an AI assistant for Aisyncy Recharge, a WhatsApp-based mobile recharge service. "
                    "Your name is Aisyncy AI. Keep your responses friendly, brief, and to the point. "
                    "Be helpful with recharge-related queries and provide relevant information about "
                    "plans, payment options, and troubleshooting. "
                    "Use emojis occasionally to make responses more engaging. "
                    "Always end with a relevant question to continue the conversation. "
                    "If you're not sure about something, suggest contacting customer support."
                )
            }
            messages.append(system_message)
            
            # Add user history if available
            if user_history and isinstance(user_history, list):
                # Only add the most recent 5 messages to avoid token limit
                for message in user_history[-5:]:
                    messages.append(message)
            
            # Add context if available
            if context:
                context_message = {
                    "role": "system", 
                    "content": f"Context about the user: {context}"
                }
                messages.append(context_message)
            
            # Add the current user query
            messages.append({"role": "user", "content": user_query})
            
            # Call OpenAI API
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": 0.7,
                "presence_penalty": 0.6,  # Encourage diverse responses
                "frequency_penalty": 0.3,  # Reduce repetition
                "top_p": 0.9,  # Nucleus sampling
            }
            
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                ai_response = result['choices'][0]['message']['content'].strip()
                
                # Post-process the response
                ai_response = self._post_process_response(ai_response)
                
                logger.info(f"OpenAI response generated successfully: {ai_response[:50]}...")
                return ai_response
            else:
                logger.error(f"OpenAI API error: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error generating OpenAI response: {str(e)}")
            return None
            
    def _post_process_response(self, response):
        """Post-process the AI response to ensure it meets our requirements"""
        try:
            # Remove any markdown formatting
            response = response.replace('*', '').replace('_', '')
            
            # Ensure response ends with a question if it doesn't already
            if not any(response.strip().endswith(p) for p in ['?', '!']):
                response = response.strip() + " How can I help you further?"
            
            # Ensure response is not too long
            if len(response) > 180:
                # Try to find a good breaking point
                last_period = response[:180].rfind('.')
                last_question = response[:180].rfind('?')
                last_exclamation = response[:180].rfind('!')
                
                break_point = max(last_period, last_question, last_exclamation)
                if break_point > 0:
                    response = response[:break_point + 1]
                else:
                    response = response[:177] + "..."
            
            return response
            
        except Exception as e:
            logger.error(f"Error post-processing response: {str(e)}")
            return response
    
    def enhance_response(self, standard_response, user_query, user_data=None):
        """Enhance a standard response with AI-generated content"""
        if not self.enabled:
            return standard_response
            
        try:
            # For text responses, enhance the content
            if isinstance(standard_response, dict) and standard_response.get('type') == 'text':
                original_text = standard_response.get('text', {}).get('body', '')
                
                # Use a specific prompt for enhancement
                enhancement_prompt = (
                    f"The user asked: '{user_query}'\n\n"
                    f"My standard response is: '{original_text}'\n\n"
                    "Please enhance this response to be more helpful, friendly, and personalized "
                    "while keeping it concise. Don't make up information that wasn't in the original response."
                )
                
                enhanced_text = self.generate_response(enhancement_prompt)
                
                # Only update if we got a valid response
                if enhanced_text:
                    standard_response['text']['body'] = enhanced_text
                    
            return standard_response
                
        except Exception as e:
            logger.error(f"Error enhancing response: {str(e)}")
            return standard_response
    
    def handle_customer_support(self, user_query, phone_number, user_history=None):
        """Handle complex customer support queries with AI"""
        if not self.enabled:
            return None
            
        # Create a specialized system prompt for customer support
        support_prompt = (
            "You are a customer support specialist for Aisyncy Recharge service. "
            "The user has a support query that needs to be addressed professionally. "
            "Provide a helpful, empathetic response that addresses their concern. "
            "Keep your response under 250 characters as this is for WhatsApp. "
            f"User phone: {phone_number}. Query: {user_query}"
        )
        
        response = self.generate_response(support_prompt, max_tokens=250)
        
        if response:
            return {
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": phone_number,
                "type": "text",
                "text": {
                    "body": response
                }
            }
        
        return None
    
    def classify_user_intent(self, message):
        """Classify user intent to route to appropriate handlers"""
        if not self.enabled:
            return "unknown"
            
        try:
            classification_prompt = (
                f"Classify the following user message into one of these categories: "
                f"'recharge', 'plan_inquiry', 'payment', 'complaint', 'greeting', 'general_query'. "
                f"Message: '{message}'\n\nCategory:"
            )
            
            response = self.generate_response(classification_prompt, max_tokens=20)
            
            if response:
                # Clean up response to get just the category
                category = response.strip().lower()
                for valid_category in ['recharge', 'plan_inquiry', 'payment', 'complaint', 'greeting', 'general_query']:
                    if valid_category in category:
                        return valid_category
            
            return "unknown"
                
        except Exception as e:
            logger.error(f"Error classifying user intent: {str(e)}")
            return "unknown"


# Create a singleton instance
openai_helper = OpenAIHelper() 