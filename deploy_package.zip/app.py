import sys
import os

# Add the 'src' directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from flask import Flask, request, Response, jsonify, render_template, session, redirect, url_for, flash
import requests
import logging
import json
from pymongo import MongoClient
from dotenv import load_dotenv
from functools import wraps
from datetime import datetime, timedelta
import os
from celery import Celery
from flask_decorator import admin_required

# Initialize Celery
celery = Celery('aisyncy',
                broker=os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0'),
                backend=os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0'))

# Configure Celery
celery.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
)

try:
    from src.chatflow.ChatFlowController_new import RechargeController  # type: ignore 
    recharge_controller = RechargeController()  # Initialize RechargeController
except ModuleNotFoundError:
    logging.error("Module 'ChatFlowController' could not be imported. Ensure it exists in 'src/chatflow'.")
    recharge_controller = None  # Set to None to avoid runtime errors
try:
    from src.error_handler import register_error_handlers  # Adjusted import for error_handler
except ImportError:
    logging.warning("Module 'src.error_handler' could not be imported. Ensure it exists.")

try:
    from src.config import (
        SECRET_KEY, MONGO_URI, ADMIN_USERNAME, ADMIN_PASSWORD,
        WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_ACCESS_TOKEN, LOG_LEVEL
    )  # Adjusted import for config
except ImportError:
    logging.warning("Module 'src.config' could not be imported. Ensure it exists.")
from flask_wtf.csrf import CSRFProtect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired
from flask_socketio import SocketIO, emit
from forms import LoginForm, SupportAgentForm, MessageTemplateForm
from src.models import (
    UserProfile, ChatAssignment, RechargeRequest, RechargeHistory,
    AutoRechargeSettings, SupportAgent, MessageTemplate,
    CHAT_STATUS, PAYMENT_STATUS, RECHARGE_STATUS
)
from src.recharge_manager import RechargeManager
from src.recharge_api import recharge_api
import time

# Load environment variables
load_dotenv()

# Admin credentials
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')

app = Flask(__name__)
app.secret_key = os.urandom(24)
logging.basicConfig(level=LOG_LEVEL)
VERIFY_TOKEN = "12345"  # Your WhatsApp verify token

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

csrf = CSRFProtect(app)

# MongoDB Connection
try:
    mongo_client = MongoClient(os.getenv('MONGO_URI'))
    db = mongo_client.get_database('aisyncy')
    
    # Create collections for new features
    db.create_collection('chat_assignments')
    db.create_collection('user_profiles')
    db.create_collection('recharge_requests')
    db.create_collection('recharge_history')
    db.create_collection('auto_recharge_settings')
    db.create_collection('support_agents')
    db.create_collection('message_templates')
    
    # Create indexes
    db.chat_assignments.create_index([('phone_number', 1)])
    db.user_profiles.create_index([('phone_number', 1)])
    db.recharge_requests.create_index([('phone_number', 1)])
    db.recharge_history.create_index([('phone_number', 1)])
    db.auto_recharge_settings.create_index([('phone_number', 1)])
    db.support_agents.create_index([('agent_id', 1)])
    
    logging.info("Connected to MongoDB successfully and created new collections!")
except Exception as e:
    logging.error(f"Failed to connect to MongoDB: {str(e)}")

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# In-memory storage (replace with database in production)
users = {}
chats = {}
agents = []
tags = {}
sessions = {}

# Add this after MongoDB connection setup
class RechargeRequest:
    def __init__(self, db):
        self.collection = db.recharge_requests

    def create_request(self, data):
        request_data = {
            'phone_number': data.get('phone_number'),
            'operator': data.get('operator'),
            'user_name': data.get('user_name'),
            'plan_amount': data.get('plan_amount'),
            'plan_validity': data.get('plan_validity'),
            'plan_description': data.get('plan_description'),
            'payment_mode': data.get('payment_mode', 'pending'),
            'payment_status': data.get('payment_status', 'pending'),
            'recharge_status': data.get('recharge_status', 'pending'),
            'created_at': datetime.utcnow(),
            'updated_at': datetime.utcnow()
        }
        return self.collection.insert_one(request_data)

    def update_status(self, request_id, **kwargs):
        update_data = {
            'updated_at': datetime.utcnow(),
            **kwargs
        }
        return self.collection.update_one(
            {'_id': request_id},
            {'$set': update_data}
        )

    def get_all_requests(self, status=None):
        query = {}
        if status:
            query['recharge_status'] = status
        return list(self.collection.find(query).sort('created_at', -1))

    def get_user_requests(self, phone_number):
        return list(self.collection.find(
            {'phone_number': phone_number}
        ).sort('created_at', -1))

# Initialize RechargeRequest handler
recharge_requests = RechargeRequest(db)

# Initialize RechargeManager
recharge_manager = RechargeManager(db)

@app.route('/')
def home():
    return render_template('index.html')

def send_whatsapp_message(phone_number, message):
    if not WHATSAPP_PHONE_NUMBER_ID or not WHATSAPP_ACCESS_TOKEN:
        logger.error("WhatsApp credentials not configured")
        return False

    url = f"https://graph.facebook.com/v17.0/{WHATSAPP_PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }
    
    # Format phone number (remove any spaces or special characters)
    phone_number = ''.join(filter(str.isdigit, phone_number))
    
    # Add country code if not present
    if not phone_number.startswith('91'):
        phone_number = '91' + phone_number
    
    if isinstance(message, dict):
        # Message is already formatted
        data = message
        if 'to' not in data:
            data['to'] = phone_number
    else:
        # Text message needs formatting
        data = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": phone_number,
            "type": "text",
            "text": {"body": message}
        }
    
    try:
        logger.info(f"Sending message to WhatsApp API: {json.dumps(data)}")
        response = requests.post(url, headers=headers, json=data)
        response_data = response.json()
        
        if response.status_code == 200:
            logger.info(f"WhatsApp API response: {json.dumps(response_data)}")
            return True
        else:
            logger.error(f"WhatsApp API error: {response.status_code} - {json.dumps(response_data)}")
            return False
            
    except requests.exceptions.RequestException as e:
        logger.error(f"Error sending message to WhatsApp API: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error sending message: {str(e)}")
        return False

@app.route('/webhook', methods=['GET', 'POST'])
@csrf.exempt
def webhook():
    if request.method == 'GET':
        mode = request.args.get('hub.mode')
        token = request.args.get('hub.verify_token')
        challenge = request.args.get('hub.challenge')

        logger.info(f"Webhook verification request - Mode: {mode}, Token: {token}")
        
        if mode and token:
            if mode == 'subscribe' and token == VERIFY_TOKEN:
                logger.info("✅ Webhook verified successfully")
                return challenge, 200
            else:
                logger.warning(f"❌ Verification failed - Expected token: {VERIFY_TOKEN}, Received: {token}")
                return 'Verification token mismatch', 403
        return 'Missing parameters', 400
    
    if request.method == 'POST':
        try:
            data = request.get_json()
            logger.info(f"📨 Received webhook data: {json.dumps(data, indent=2)}")

            if not data:
                logger.error("❌ Empty request body")
                return 'Empty request body', 400

            # Process the message
            entries = data.get('entry', [])
            for entry in entries:
                changes = entry.get('changes', [])
                for change in changes:
                    value = change.get('value', {})
                    messages = value.get('messages', [])
                    
                    for message in messages:
                        phone_number = message.get('from')
                        message_type = message.get('type')
                        message_id = message.get('id')
                        
                        logger.info(f"📱 Message from {phone_number} (Type: {message_type}, ID: {message_id})")

                        message_body = None
                        if message_type == 'text':
                            message_body = message.get('text', {}).get('body', '')
                        elif message_type == 'interactive':
                            interactive = message.get('interactive', {})
                            if interactive.get('type') == 'button_reply':
                                message_body = interactive.get('button_reply', {}).get('id')
                            elif interactive.get('type') == 'list_reply':
                                message_body = interactive.get('list_reply', {}).get('id')
                        
                        if message_body:
                            # Store message in database
                            message_data = {
                                'phone_number': phone_number,
                                'message': message_body,
                                'sender': 'user',
                                'timestamp': datetime.utcnow()
                            }
                            db.messages.insert_one(message_data)
                            
                            # Process message with recharge controller
                            if recharge_controller:
                                try:
                                    response_message = recharge_controller.process_recharge(phone_number, message_body)
                                    if response_message:
                                        # Store bot response in database
                                        bot_message_data = {
                                            'phone_number': phone_number,
                                            'message': response_message.get('text', {}).get('body', '') if isinstance(response_message, dict) else response_message,
                                            'sender': 'bot',
                                            'timestamp': datetime.utcnow(),
                                            'direction': 'outgoing'
                                        }
                                        db.messages.insert_one(bot_message_data)
                                        
                                        # Send message via WhatsApp
                                        send_whatsapp_message(phone_number, response_message)
                                        logger.info(f"✅ Response sent to {phone_number}")
                                except Exception as e:
                                    logger.error(f"❌ Error processing message: {str(e)}")
                                    return 'Error processing message', 500

            return 'EVENT_RECEIVED', 200
            
        except Exception as e:
            logger.error(f"❌ Webhook error: {str(e)}")
            logger.error(f"Request data: {request.data}")
            return 'Internal server error', 500

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if 'admin_logged_in' in session and session['admin_logged_in']:
        return redirect(url_for('admin_home'))  # Redirect to new admin home page
    
    form = LoginForm()
    if request.method == 'POST' and form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            session['admin_username'] = username
            flash('Logged in successfully!', 'success')
            return redirect(url_for('admin_home'))  # Redirect to new admin home page
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('admin_login.html', form=form)

@app.route('/admin/logout')
def admin_logout():
    # Clear admin session data
    session.pop('admin_logged_in', None)
    session.pop('admin_username', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('admin_login'))

# WebSocket event handlers
@socketio.on('connect')
def handle_connect():
    if 'admin_logged_in' in session:
        join_room('admin_room')
        emit('connection_status', {'status': 'connected'})

@socketio.on('get_user_list')
def handle_get_user_list():
    emit('user_list', get_active_users())

@socketio.on('send_message')
def handle_send_message(data):
    try:
        phone_number = data['phone_number']
        message = data['message']
        
        # Send message via WhatsApp
        send_whatsapp_message(phone_number, message)
        
        # Store message in database
        db.messages.insert_one({
            'phone_number': phone_number,
            'message': message,
            'direction': 'outgoing',
            'timestamp': datetime.utcnow(),
            'sent_by': session.get('admin_username', 'admin')
        })
        
        # Emit to all admins
        emit('new_message', {
            'phone_number': phone_number,
            'message': message,
            'direction': 'outgoing',
            'timestamp': datetime.utcnow().isoformat(),
            'sent_by': session.get('admin_username', 'admin')
        }, room='admin_room')
        
    except Exception as e:
        logger.error(f"Error sending message: {str(e)}")
        emit('error', {'message': 'संदेश भेजने में त्रुटि हुई'})

@socketio.on('disconnect')
def handle_disconnect():
    pass

def get_active_users():
    try:
        # Get users with recent messages
        users = list(db.messages.aggregate([
            {
                '$group': {
                    '_id': '$phone_number',
                    'last_message': {'$last': '$message'},
                    'last_active': {'$last': '$timestamp'},
                    'status': {'$last': '$direction'}
                }
            },
            {
                '$project': {
                    'phone_number': '$_id',
                    'last_message': 1,
                    'last_active': 1,
                    'status': 1
                }
            }
        ]))
        
        # Format the data
        for user in users:
            user['status'] = 'online' if (datetime.utcnow() - user['last_active']).total_seconds() < 300 else 'offline'
            user['last_active'] = user['last_active'].strftime('%Y-%m-%d %H:%M:%S')
            
        return users
    except Exception as e:
        logging.error(f"Error getting active users: {str(e)}")
        return []

# Admin panel routes
@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    try:
        # Get all active chats
        active_chats = db.chat_assignments.find({
            'status': {'$in': [CHAT_STATUS['UNREAD'], CHAT_STATUS['IN_PROGRESS']]}
        }).sort('assigned_at', -1)
        
        # Get recent messages for each chat
        chat_data = []
        for chat in active_chats:
            messages = db.messages.find({
                'phone_number': chat['phone_number']
            }).sort('timestamp', -1).limit(10)
            
            chat_data.append({
                'chat': chat,
                'messages': list(messages)
            })
        
        return render_template('admin/dashboard.html', 
                             chat_data=chat_data,
                             active_chats=len(chat_data))
    except Exception as e:
        logger.error(f"Error in admin dashboard: {str(e)}")
        flash('एक त्रुटि हुई है। कृपया पुनः प्रयास करें।', 'error')
        return redirect(url_for('admin_login'))

@app.route('/admin/home')
@admin_required
def admin_home():
    # Get some basic stats for the dashboard
    total_customers = db.user_profiles.count_documents({})
    total_recharges = db.recharge_history.count_documents({})
    active_chats = db.chat_assignments.count_documents({'status': 'active'})
    
    # Calculate total revenue
    revenue_pipeline = [
        {
            '$group': {
                '_id': None,
                'total_revenue': {'$sum': '$amount'}
            }
        }
    ]
    revenue_result = list(db.recharge_history.aggregate(revenue_pipeline))
    total_revenue = revenue_result[0]['total_revenue'] if revenue_result else 0
    
    return render_template('admin/home.html',
                          total_customers=total_customers,
                          total_recharges=total_recharges,
                          active_chats=active_chats,
                          total_revenue=total_revenue)

@app.route('/admin/user/<phone_number>')
@admin_required
def user_details(phone_number):
    try:
        # Get user details
        user = db.users.find_one({'phone_number': phone_number})
        if not user:
            return "User not found", 404
            
        # Get recharge history
        recharge_history = list(db.recharges.find(
            {'phone_number': phone_number}
        ).sort('date', -1))
        
        # Get payment history
        payments = list(db.payments.find(
            {'phone_number': phone_number}
        ).sort('date', -1))
        
        # Get current plan
        current_plan = db.recharges.find_one({
            'phone_number': phone_number,
            'status': 'success',
            'valid_until': {'$gt': datetime.utcnow()}
        })
        
        return render_template('user_details.html',
                             user=user,
                             history=recharge_history,
                             payments=payments,
                             current_plan=current_plan)
                             
    except Exception as e:
        logging.error(f"Error in user_details: {str(e)}")
        return "Internal server error", 500

@app.route('/api/chat/<phone_number>', methods=['GET'])
def get_chat_history(phone_number):
    try:
        # Format phone number
        phone_number = ''.join(filter(str.isdigit, phone_number))
        if not phone_number.startswith('91'):
            phone_number = '91' + phone_number

        # Get messages from database
        messages = list(db.messages.find(
            {'phone_number': phone_number},
            {'_id': 0, 'phone_number': 1, 'message': 1, 'sender': 1, 'timestamp': 1, 'direction': 1}
        ).sort('timestamp', 1))

        # Format messages for frontend
        formatted_messages = []
        for msg in messages:
            formatted_messages.append({
                'phone_number': msg['phone_number'],
                'message': msg['message'],
                'sender': msg.get('sender', 'user'),
                'timestamp': msg['timestamp'].isoformat(),
                'direction': msg.get('direction', 'incoming')
            })

        return jsonify({'messages': formatted_messages})
    except Exception as e:
        logger.error(f"Error in get_chat_history: {str(e)}")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

@app.route('/api/send-reply', methods=['POST'])
@admin_required
def send_reply():
    try:
        data = request.get_json()
        phone_number = data.get('phone_number')
        message = data.get('message')
        
        if not phone_number or not message:
            return jsonify({'error': 'Missing required fields'}), 400
            
        # Format phone number if needed (remove any spaces or special characters)
        phone_number = ''.join(filter(str.isdigit, phone_number))
        
        # Send message via WhatsApp
        success = send_whatsapp_message(phone_number, message)
        
        if success:
            # Store message in database
            db.messages.insert_one({
                'phone_number': phone_number,
                'message': message,
                'direction': 'outgoing',
                'timestamp': datetime.utcnow()
            })
            
            # Update user's last active time
            db.users.update_one(
                {'phone_number': phone_number},
                {
                    '$set': {'last_active': datetime.utcnow()},
                    '$setOnInsert': {'phone_number': phone_number}
                },
                upsert=True
            )
            
            # Emit to WebSocket
            socketio.emit('message', {
                'phone_number': phone_number,
                'message': message,
                'direction': 'outgoing'
            })
            
            return jsonify({'success': True})
        else:
            return jsonify({'error': 'Failed to send message'}), 500
            
    except Exception as e:
        logging.error(f"Error sending reply: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/manual-recharge', methods=['POST'])
@admin_required
def trigger_manual_recharge():
    try:
        data = request.get_json()
        phone_number = data.get('phone_number')
        amount = data.get('amount')
        days = data.get('days')
        payment_method = data.get('payment_method')
        
        if not all([phone_number, amount, days, payment_method]):
            return jsonify({'error': 'Missing required fields'}), 400
            
        # Create recharge record
        recharge_id = db.recharges.insert_one({
            'phone_number': phone_number,
            'amount': amount,
            'days': days,
            'status': 'pending',
            'payment_method': payment_method,
            'created_at': datetime.utcnow()
        }).inserted_id
        
        # Here you would integrate with your payment gateway
        # For now, we'll simulate a successful payment
        db.recharges.update_one(
            {'_id': recharge_id},
            {
                '$set': {
                    'status': 'success',
                    'transaction_id': f"TXN_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                    'valid_until': datetime.utcnow() + timedelta(days=days)
                }
            }
        )
        
        # Send success message to user
        success_message = f"✅ Recharge Successful!\nAmount: ₹{amount}\nValidity: {days} Days"
        send_whatsapp_message(phone_number, success_message)
        
        return jsonify({'success': True})
        
    except Exception as e:
        logging.error(f"Error in manual recharge: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/messages', methods=['GET', 'POST'])
def handle_messages():
    if request.method == 'POST':
        data = request.get_json()
        # Process message here
        return jsonify({"status": "success", "message": "Message received"})
    else:
        # Return recent messages
        messages = [] # Replace with actual message fetching logic
        return jsonify(messages)

@app.errorhandler(404)
def not_found_error(e):  # Defined missing function
    return jsonify({
        "error": "Not Found",
        "message": "The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again."
    }), 404

def send_message(to, text):
    url = "https://graph.facebook.com/v13.0/me/messages"
    access_token = os.getenv('WHATSAPP_ACCESS_TOKEN')
    if not access_token:
        logging.error("WhatsApp access token not found in environment variables")
        return False

    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "text": {"body": text}
    }
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        logging.info(f"Message sent successfully to {to}")
        return True
    except requests.exceptions.HTTPError as e:
        logging.error(f"HTTP Error sending message to {to}: {str(e)}")
        if response.status_code == 401:
            logging.error("Authentication failed. Please check WhatsApp access token.")
        return False
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to send message to {to}: {str(e)}")
        return False

def send_button(to, text, button_text):
    url = "https://graph.facebook.com/v13.0/me/messages"
    access_token = os.getenv('WHATSAPP_ACCESS_TOKEN')
    if not access_token:
        logging.error("WhatsApp access token not found in environment variables")
        return False

    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "interactive",
        "interactive": {
            "type": "button",
            "body": {"text": text},
            "action": {
                "buttons": [
                    {"type": "reply", "reply": {"id": "recharge_now", "title": button_text}}
                ]
            }
        }
    }
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        logging.info(f"Button message sent successfully to {to}")
        return True
    except requests.exceptions.HTTPError as e:
        logging.error(f"HTTP Error sending button message to {to}: {str(e)}")
        if response.status_code == 401:
            logging.error("Authentication failed. Please check WhatsApp access token.")
        return False
    except requests.exceptions.RequestException as e:
        logging.error(f"Failed to send button message to {to}: {str(e)}")
        return False

# Register the custom error handler
app.register_error_handler(404, not_found_error)

# Register error handlers
if 'register_error_handlers' in locals():
    register_error_handlers(app)

@app.route('/api/send-manual-message', methods=['POST'])
@admin_required
def send_manual_message():
    if not session.get('admin_logged_in'):
        return jsonify({'error': 'Unauthorized'}), 401
        
    try:
        data = request.get_json()
        if not data or 'phone_number' not in data or 'message' not in data:
            return jsonify({'error': 'Missing required fields'}), 400

        phone_number = data['phone_number']
        message = data['message']

        success = send_whatsapp_message(phone_number, message)
        
        if not success:
            return jsonify({'error': 'Failed to send message'}), 500

        return jsonify({'status': 'success'})

    except Exception as e:
        logging.error(f"Error sending manual message: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/active-chats', methods=['GET'])
def get_active_chats():
    try:
        # Get active users from messages collection
        active_users = list(db.messages.aggregate([
            {
                '$match': {
                    'timestamp': {'$gte': datetime.utcnow() - timedelta(hours=24)}
                }
            },
            {
                '$group': {
                    '_id': '$phone_number',
                    'last_message': {'$last': '$message'},
                    'timestamp': {'$last': '$timestamp'},
                    'sender': {'$last': '$sender'},
                    'direction': {'$last': '$direction'}
                }
            },
            {
                '$project': {
                    'phone_number': '$_id',
                    'last_message': 1,
                    'timestamp': 1,
                    'sender': 1,
                    'direction': 1
                }
            },
            {
                '$sort': {'timestamp': -1}
            }
        ]))

        # Get user details for each active user
        for user in active_users:
            user_profile = db.user_profiles.find_one(
                {'phone_number': user['phone_number']},
                {'_id': 0, 'name': 1, 'email': 1, 'whatsapp_opted': 1}
            )
            if user_profile:
                user.update(user_profile)

        return jsonify(active_users)
    except Exception as e:
        logger.error(f"Error in get_active_chats: {str(e)}")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

@app.route('/api/assign-chat', methods=['POST'])
@admin_required
def assign_chat():
    """Assign chat to a support agent"""
    data = request.get_json()
    phone_number = data.get('phone_number')
    agent_id = data.get('agent_id')
    agent_name = data.get('agent_name')
    
    if not all([phone_number, agent_id, agent_name]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    ChatAssignment.assign(phone_number, agent_id, agent_name)
    return jsonify({'success': True})

@app.route('/api/update-chat-status', methods=['POST'])
@admin_required
def update_chat_status():
    """Update chat status"""
    data = request.get_json()
    phone_number = data.get('phone_number')
    status = data.get('status')
    
    if not all([phone_number, status]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    if status not in CHAT_STATUS.values():
        return jsonify({'error': 'Invalid status'}), 400
    
    ChatAssignment.update_status(phone_number, status)
    return jsonify({'success': True})

@app.route('/api/recharge-requests')
@admin_required
def get_recharge_requests():
    """Get all recharge requests"""
    status = request.args.get('status')
    requests = recharge_requests.get_all_requests(status)
    return jsonify(requests)

@app.route('/api/trigger-recharge', methods=['POST'])
@admin_required
def trigger_recharge():
    """Trigger manual recharge"""
    try:
        data = request.get_json()
        phone_number = data.get('phone_number')
        
        if not phone_number:
            return jsonify({'error': 'Missing phone number'}), 400
        
        # Get recharge request
        recharge_request = db.recharge_requests.find_one({'phone_number': phone_number})
        if not recharge_request:
            return jsonify({'error': 'No recharge request found'}), 404
        
        # Verify payment first
        payment_details = recharge_request.get('payment_details', {})
        if payment_details.get('status') != 'completed':
            return jsonify({'error': 'Payment not completed'}), 400
            
        # Initiate recharge
        result = recharge_api.initiate_recharge(
            phone_number=recharge_request['recharge_number'],
            operator=recharge_request['operator'],
            amount=recharge_request['plan_details']['amount'],
            plan_id=recharge_request['plan_details'].get('plan_id')
        )
        
        if result['success']:
            # Update request status
            db.recharge_requests.update_one(
                {'phone_number': phone_number},
                {
                    '$set': {
                        'recharge_status': 'processing',
                        'transaction_id': result['transaction_id'],
                        'updated_at': datetime.utcnow()
                    }
                }
            )
            
            # Start status check in background
            check_recharge_status.delay(phone_number, result['transaction_id'])
            
            # Send notification to user
            send_whatsapp_message(
                phone_number,
                f"Your recharge of ₹{recharge_request['plan_details']['amount']} is being processed. "
                f"Transaction ID: {result['transaction_id']}"
            )
            
            return jsonify({
                'success': True,
                'transaction_id': result['transaction_id']
            })
        else:
            logger.error(f"Recharge failed: {result.get('error')}")
            return jsonify({
                'error': 'Failed to initiate recharge',
                'details': result.get('error')
            }), 500
            
    except Exception as e:
        logger.error(f"Error in trigger_recharge: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@celery.task
def check_recharge_status(phone_number, transaction_id):
    """Background task to check recharge status"""
    try:
        max_retries = 5
        retry_delay = 5  # seconds
        
        for _ in range(max_retries):
            result = recharge_api.check_status(transaction_id)
            
            if result['success']:
                status = result['status']
                
                # Update request status
                db.recharge_requests.update_one(
                    {'phone_number': phone_number},
                    {
                        '$set': {
                            'recharge_status': status,
                            'updated_at': datetime.utcnow()
                        }
                    }
                )
                
                if status == 'success':
                    # Add to recharge history
                    request = db.recharge_requests.find_one({'phone_number': phone_number})
                    RechargeHistory.add(
                        phone_number=phone_number,
                        operator=request['operator'],
                        plan=request['plan_details'],
                        amount=request['plan_details']['amount'],
                        status='success'
                    )
                    
                    # Send success message
                    send_whatsapp_message(
                        phone_number,
                        f"✅ Recharge Successful!\n"
                        f"Amount: ₹{request['plan_details']['amount']}\n"
                        f"Operator: {request['operator'].upper()}\n"
                        f"Transaction ID: {transaction_id}"
                    )
                    return
                
                elif status == 'failed':
                    # Send failure message
                    send_whatsapp_message(
                        phone_number,
                        f"❌ Recharge Failed\n"
                        f"Transaction ID: {transaction_id}\n"
                        f"Please contact support for assistance."
                    )
                    return
            
            time.sleep(retry_delay)
        
        # If we reach here, status check timed out
        db.recharge_requests.update_one(
            {'phone_number': phone_number},
            {
                '$set': {
                    'recharge_status': 'timeout',
                    'updated_at': datetime.utcnow()
                }
            }
        )
        
        send_whatsapp_message(
            phone_number,
            f"⚠️ Recharge Status Unknown\n"
            f"Transaction ID: {transaction_id}\n"
            f"Please contact support to check the status."
        )
        
    except Exception as e:
        logger.error(f"Error checking recharge status: {str(e)}")
        db.recharge_requests.update_one(
            {'phone_number': phone_number},
            {
                '$set': {
                    'recharge_status': 'error',
                    'error_details': str(e),
                    'updated_at': datetime.utcnow()
                }
            }
        )

@app.route('/api/recharge-history/<phone_number>')
@admin_required
def get_recharge_history(phone_number):
    """Get recharge history for a user"""
    history = RechargeHistory.get_history(phone_number)
    return jsonify(history)

@app.route('/api/auto-recharge/settings', methods=['GET', 'POST'])
@admin_required
def auto_recharge_settings():
    """Get or update auto recharge settings"""
    if request.method == 'GET':
        phone_number = request.args.get('phone_number')
        if not phone_number:
            return jsonify({'error': 'Missing phone number'}), 400
        settings = AutoRechargeSettings.get_settings(phone_number)
        return jsonify(settings or {})
    
    data = request.get_json()
    phone_number = data.get('phone_number')
    if not phone_number:
        return jsonify({'error': 'Missing phone number'}), 400
    
    AutoRechargeSettings.create_or_update(phone_number, data)
    return jsonify({'success': True})

@app.route('/api/support-agents', methods=['GET', 'POST'])
@admin_required
def support_agents():
    """Get all support agents or create new one"""
    if request.method == 'GET':
        agents = SupportAgent.get_all()
        return jsonify(agents)
    
    data = request.get_json()
    agent_id = data.get('agent_id')
    name = data.get('name')
    email = data.get('email')
    
    if not all([agent_id, name, email]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    SupportAgent.create(agent_id, name, email)
    return jsonify({'success': True})

@app.route('/api/message-templates', methods=['GET', 'POST'])
@admin_required
def message_templates():
    """Get all message templates or create new one"""
    if request.method == 'GET':
        templates = MessageTemplate.get_all()
        return jsonify(templates)
    
    data = request.get_json()
    title = data.get('title')
    content = data.get('content')
    
    if not all([title, content]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    MessageTemplate.create(title, content)
    return jsonify({'success': True})

@app.route('/api/analytics')
@admin_required
def get_analytics():
    """Get analytics data"""
    today = datetime.utcnow().date()
    week_ago = today - timedelta(days=7)
    
    # Get today's recharges
    today_recharges = db.recharge_history.count_documents({
        'timestamp': {'$gte': datetime.combine(today, datetime.min.time())}
    })
    
    # Get this week's recharges
    week_recharges = db.recharge_history.count_documents({
        'timestamp': {'$gte': datetime.combine(week_ago, datetime.min.time())}
    })
    
    # Get active chats
    active_chats = db.chat_assignments.count_documents({
        'status': {'$in': [CHAT_STATUS['UNREAD'], CHAT_STATUS['IN_PROGRESS']]}
    })
    
    # Get chart data (last 7 days)
    chart_data = []
    chart_labels = []
    for i in range(7):
        date = week_ago + timedelta(days=i)
        count = db.recharge_history.count_documents({
            'timestamp': {
                '$gte': datetime.combine(date, datetime.min.time()),
                '$lt': datetime.combine(date + timedelta(days=1), datetime.min.time())
            }
        })
        chart_data.append(count)
        chart_labels.append(date.strftime('%Y-%m-%d'))
    
    return jsonify({
        'today_recharges': today_recharges,
        'week_recharges': week_recharges,
        'active_chats': active_chats,
        'chart_data': chart_data,
        'chart_labels': chart_labels
    })

@app.route('/api/send-message', methods=['POST'])
@csrf.exempt  # Exempt this route from CSRF protection since we're handling it manually
def send_message():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'Invalid request data'}), 400

        phone_number = data.get('phone_number')
        message = data.get('message')
        sender = data.get('sender', 'admin')

        if not phone_number or not message:
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        # Format phone number
        phone_number = ''.join(filter(str.isdigit, phone_number))
        if not phone_number.startswith('91'):
            phone_number = '91' + phone_number

        # Send message via WhatsApp API
        try:
            success = send_whatsapp_message(phone_number, message)
            if not success:
                return jsonify({'success': False, 'error': 'Failed to send message'}), 500
        except Exception as e:
            logger.error(f"Error sending WhatsApp message: {str(e)}")
            return jsonify({'success': False, 'error': 'Failed to send message'}), 500

        # Store message in database
        message_data = {
            'phone_number': phone_number,
            'message': message,
            'sender': sender,
            'timestamp': datetime.utcnow(),
            'direction': 'outgoing' if sender == 'admin' else 'incoming'
        }
        
        db.messages.insert_one(message_data)

        # Update user's last active time
        db.users.update_one(
            {'phone_number': phone_number},
            {
                '$set': {
                    'last_active': datetime.utcnow(),
                    'phone_number': phone_number
                }
            },
            upsert=True
        )

        # Broadcast message to all connected clients
        socketio.emit('new_message', {
            'phone_number': phone_number,
            'message': message,
            'sender': sender,
            'timestamp': message_data['timestamp'].isoformat(),
            'direction': message_data['direction']
        })

        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error in send_message: {str(e)}")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

@app.route('/admin/add-agent', methods=['GET', 'POST'])
@admin_required
def add_agent():
    form = SupportAgentForm()
    if form.validate_on_submit():
        try:
            SupportAgent.create(
                agent_id=form.agent_id.data,
                name=form.name.data,
                email=form.email.data
            )
            flash('Support agent added successfully!', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            flash(f'Error adding support agent: {str(e)}', 'error')
    return render_template('add_agent.html', form=form)

@app.route('/admin/add-template', methods=['GET', 'POST'])
@admin_required
def add_template():
    form = MessageTemplateForm()
    if form.validate_on_submit():
        try:
            template_data = {
                'title': form.title.data,
                'message_type': form.message_type.data,
                'content': form.content.data,
                'created_at': datetime.utcnow()
            }

            # Add type-specific data
            if form.message_type.data == 'button':
                # Collect non-empty button options
                button_options = []
                for i in range(1, 4):
                    option = getattr(form, f'button_option{i}').data
                    if option and option.strip():
                        button_options.append(option.strip())
                
                template_data.update({
                    'button_text': form.button_text.data,
                    'button_options': button_options
                })
            elif form.message_type.data == 'list':
                # Collect non-empty list options
                list_options = []
                for i in range(1, 11):
                    option = getattr(form, f'list_option{i}').data
                    if option and option.strip():
                        list_options.append(option.strip())
                
                template_data.update({
                    'list_title': form.list_title.data,
                    'list_options': list_options
                })
            elif form.message_type.data == 'contact':
                template_data.update({
                    'contact_name': form.contact_name.data,
                    'contact_phone': form.contact_phone.data
                })
            elif form.message_type.data == 'image':
                template_data.update({
                    'image_url': form.image_url.data
                })

            MessageTemplate.create(**template_data)
            flash('Message template added successfully!', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            flash(f'Error adding message template: {str(e)}', 'error')
    return render_template('add_template.html', form=form)

@app.route('/admin/agents')
@admin_required
def list_agents():
    agents = SupportAgent.get_all()
    return render_template('admin_dashboard.html', agents=agents)

@app.route('/admin/templates')
@admin_required
def list_templates():
    templates = MessageTemplate.get_all()
    return render_template('admin_dashboard.html', templates=templates)

# Add error handler for API endpoints
@app.errorhandler(Exception)
def handle_error(error):
    logger.error(f"Error occurred: {str(error)}")
    if request.path.startswith('/api/'):
        # Return JSON response for API endpoints
        return jsonify({
            'success': False,
            'error': str(error)
        }), 500
    else:
        # Return HTML response for other endpoints
        return render_template('error.html', error=str(error)), 500

# Update the main run statement to use socketio
if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=8080, debug=False, use_reloader=False)

@app.route('/api/delete-agent', methods=['POST'])
def delete_agent():
    data = request.get_json()
    agent_id = data.get('agent_id')
    if not agent_id:
        return jsonify({'success': False, 'error': 'Agent ID required'}), 400
    result = mongo_client.get_database('aisyncy').support_agents.delete_one({'agent_id': agent_id})
    if result.deleted_count == 1:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Agent not found'})

@app.route('/api/delete-template', methods=['POST'])
def delete_template():
    data = request.get_json()
    template_id = data.get('template_id')
    if not template_id:
        return jsonify({'success': False, 'error': 'Template ID required'}), 400
    result = mongo_client.get_database('aisyncy').message_templates.delete_one({'template_id': template_id})
    if result.deleted_count == 1:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Template not found'})

@app.route('/api/update-name', methods=['POST'])
def update_name():
    data = request.json
    phone_number = data.get('phone_number')
    new_name = data.get('name')
    
    if phone_number and new_name:
        if phone_number not in users:
            users[phone_number] = {}
        users[phone_number]['name'] = new_name
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/add-tag', methods=['POST'])
def add_tag():
    data = request.json
    phone_number = data.get('phone_number')
    tag = data.get('tag')
    
    if phone_number and tag:
        if phone_number not in tags:
            tags[phone_number] = set()
        tags[phone_number].add(tag)
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/remove-tag', methods=['POST'])
def remove_tag():
    data = request.json
    phone_number = data.get('phone_number')
    tag = data.get('tag')
    
    if phone_number and tag and phone_number in tags:
        tags[phone_number].discard(tag)
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/tags/<phone_number>')
def get_tags(phone_number):
    user_tags = list(tags.get(phone_number, set()))
    return jsonify({'success': True, 'tags': user_tags})

@app.route('/api/agents')
def get_agents():
    return jsonify({'success': True, 'agents': agents})

@app.route('/api/assign-chat', methods=['POST'])
def assign_chat():
    data = request.json
    phone_number = data.get('phone_number')
    agent_id = data.get('agent_id')
    
    if phone_number and agent_id:
        if phone_number not in users:
            users[phone_number] = {}
        users[phone_number]['assigned_agent'] = agent_id
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/reset-session', methods=['POST'])
def reset_session():
    data = request.json
    phone_number = data.get('phone_number')
    
    if phone_number:
        if phone_number in sessions:
            sessions[phone_number] = []
        # Send welcome message
        welcome_message = {
            'sender': 'bot',
            'message': {
                'text': {'body': 'Welcome to Aisyncy Recharge! How can I help you today?'}
            },
            'timestamp': datetime.now().isoformat()
        }
        if phone_number not in chats:
            chats[phone_number] = []
        chats[phone_number].append(welcome_message)
        socketio.emit('new_message', {**welcome_message, 'phone_number': phone_number})
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/close-session', methods=['POST'])
def close_session():
    data = request.json
    phone_number = data.get('phone_number')
    
    if phone_number:
        if phone_number in sessions:
            del sessions[phone_number]
        if phone_number in chats:
            chats[phone_number] = []
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/update-user-details', methods=['POST'])
def update_user_details():
    data = request.json
    phone_number = data.get('phone_number')
    details = data.get('details', {})
    
    if phone_number:
        if phone_number not in users:
            users[phone_number] = {}
        users[phone_number].update(details)
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

@app.route('/api/chat/<phone_number>')
def get_chat_history(phone_number):
    chat_history = chats.get(phone_number, [])
    return jsonify({'success': True, 'messages': chat_history})

@app.route('/api/active-chats')
def get_active_chats():
    active_chats = []
    for phone_number in chats:
        chat_messages = chats[phone_number]
        if chat_messages:
            last_message = chat_messages[-1]
            user_info = users.get(phone_number, {})
            active_chats.append({
                'phone_number': phone_number,
                'name': user_info.get('name', ''),
                'whatsapp_name': user_info.get('whatsapp_name', ''),
                'last_message': last_message.get('message', {}).get('text', {}).get('body', 'No messages'),
                'timestamp': last_message.get('timestamp'),
                'status': 'Online' if phone_number in sessions else 'Offline'
            })
    return jsonify({'success': True, 'chats': active_chats})

@app.route('/api/send-message', methods=['POST'])
def send_message():
    data = request.json
    phone_number = data.get('phone_number')
    message = data.get('message')
    sender = data.get('sender', 'admin')
    
    if phone_number and message:
        message_data = {
            'sender': sender,
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        if phone_number not in chats:
            chats[phone_number] = []
        chats[phone_number].append(message_data)
        socketio.emit('new_message', {**message_data, 'phone_number': phone_number})
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Invalid data'})

# Add some test agents
agents = [
    {'id': 1, 'name': 'Agent 1'},
    {'id': 2, 'name': 'Agent 2'},
    {'id': 3, 'name': 'Agent 3'}
]

@app.route('/api/recharge-request', methods=['POST'])
def create_recharge_request():
    try:
        data = request.json
        required_fields = ['phone_number', 'operator', 'user_name', 'plan_amount']
        
        # Validate required fields
        if not all(field in data for field in required_fields):
            return jsonify({
                'success': False,
                'error': 'Missing required fields'
            }), 400

        # Create recharge request
        result = recharge_requests.create_request(data)
        
        # Store in chat history
        request_message = {
            'sender': 'system',
            'message': {
                'type': 'recharge_request',
                'text': {
                    'body': f"Recharge Request Created\n"
                           f"Amount: ₹{data['plan_amount']}\n"
                           f"Operator: {data['operator']}\n"
                           f"Status: Pending"
                }
            },
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if data['phone_number'] not in chats:
            chats[data['phone_number']] = []
        chats[data['phone_number']].append(request_message)
        
        # Emit socket event for real-time update
        socketio.emit('new_message', {
            **request_message,
            'phone_number': data['phone_number']
        })

        return jsonify({
            'success': True,
            'request_id': str(result.inserted_id)
        })

    except Exception as e:
        logger.error(f"Error creating recharge request: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@app.route('/api/recharge-requests', methods=['GET'])
def get_recharge_requests():
    try:
        status = request.args.get('status')
        requests = recharge_requests.get_all_requests(status)
        
        # Format the response
        formatted_requests = []
        for req in requests:
            formatted_requests.append({
                'request_id': str(req['_id']),
                'phone_number': req['phone_number'],
                'operator': req['operator'],
                'user_name': req['user_name'],
                'plan_amount': req['plan_amount'],
                'plan_validity': req.get('plan_validity'),
                'plan_description': req.get('plan_description'),
                'payment_mode': req.get('payment_mode'),
                'payment_status': req.get('payment_status'),
                'recharge_status': req.get('recharge_status'),
                'created_at': req['created_at'].isoformat(),
                'updated_at': req['updated_at'].isoformat()
            })

        return jsonify({
            'success': True,
            'requests': formatted_requests
        })

    except Exception as e:
        logger.error(f"Error fetching recharge requests: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@app.route('/api/recharge-requests/<phone_number>', methods=['GET'])
def get_user_recharge_requests(phone_number):
    try:
        requests = recharge_requests.get_user_requests(phone_number)
        
        # Format the response
        formatted_requests = []
        for req in requests:
            formatted_requests.append({
                'request_id': str(req['_id']),
                'operator': req['operator'],
                'plan_amount': req['plan_amount'],
                'plan_validity': req.get('plan_validity'),
                'plan_description': req.get('plan_description'),
                'payment_mode': req.get('payment_mode'),
                'payment_status': req.get('payment_status'),
                'recharge_status': req.get('recharge_status'),
                'created_at': req['created_at'].isoformat()
            })

        return jsonify({
            'success': True,
            'requests': formatted_requests
        })

    except Exception as e:
        logger.error(f"Error fetching user recharge requests: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@app.route('/api/update-recharge-status', methods=['POST'])
def update_recharge_status():
    try:
        data = request.json
        request_id = data.get('request_id')
        
        if not request_id:
            return jsonify({
                'success': False,
                'error': 'Request ID is required'
            }), 400

        # Update status
        update_data = {}
        if 'payment_status' in data:
            update_data['payment_status'] = data['payment_status']
        if 'recharge_status' in data:
            update_data['recharge_status'] = data['recharge_status']
        if 'payment_mode' in data:
            update_data['payment_mode'] = data['payment_mode']

        result = recharge_requests.update_status(request_id, **update_data)

        if result.modified_count > 0:
            return jsonify({'success': True})
        else:
            return jsonify({
                'success': False,
                'error': 'Request not found or no changes made'
            }), 404

    except Exception as e:
        logger.error(f"Error updating recharge status: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

# Update the process_recharge function to store recharge request
def process_recharge(phone_number, operator, plan_data, user_name):
    try:
        # Create recharge request
        request_data = {
            'phone_number': phone_number,
            'operator': operator,
            'user_name': user_name,
            'plan_amount': plan_data.get('amount'),
            'plan_validity': plan_data.get('validity'),
            'plan_description': plan_data.get('description'),
            'payment_mode': 'pending',
            'payment_status': 'pending',
            'recharge_status': 'pending'
        }
        
        result = recharge_requests.create_request(request_data)
        
        if result.inserted_id:
            return {
                'success': True,
                'request_id': str(result.inserted_id),
                'message': 'Recharge request created successfully'
            }
        else:
            return {
                'success': False,
                'error': 'Failed to create recharge request'
            }
            
    except Exception as e:
        logger.error(f"Error processing recharge: {str(e)}")
        return {
            'success': False,
            'error': 'Internal server error'
        }

@app.route('/api/recharge-history', methods=['GET'])
def get_recharge_history():
    """Get recharge history"""
    try:
        phone_number = request.args.get('phone_number')
        limit = int(request.args.get('limit', 10))
        
        if phone_number:
            history = recharge_manager.get_user_history(phone_number, limit)
        else:
            # Get all history entries
            history = list(db.recharge_history.find()
                .sort('completed_at', -1)
                .limit(limit))
        
        # Format the response
        formatted_history = []
        for entry in history:
            formatted_history.append({
                'phone_number': entry['phone_number'],
                'operator': entry['operator'],
                'plan_details': entry['plan_details'],
                'transaction_id': entry['transaction_id'],
                'completed_at': entry['completed_at'].isoformat()
            })

        return jsonify({
            'success': True,
            'history': formatted_history
        })

    except Exception as e:
        logger.error(f"Error fetching recharge history: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@app.route('/api/recharge-requests', methods=['GET'])
def get_recharge_requests():
    """Get active recharge requests"""
    try:
        requests = recharge_manager.get_active_requests()
        
        # Format the response
        formatted_requests = []
        for req in requests:
            formatted_requests.append({
                'phone_number': req['phone_number'],
                'operator': req.get('operator'),
                'plan_details': req.get('plan_details'),
                'payment_details': req.get('payment_details'),
                'status': req.get('status'),
                'created_at': req['created_at'].isoformat(),
                'updated_at': req.get('updated_at', '').isoformat() if req.get('updated_at') else None
            })

        return jsonify({
            'success': True,
            'requests': formatted_requests
        })

    except Exception as e:
        logger.error(f"Error fetching recharge requests: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

# Update the existing webhook handler to emit socket events
@socketio.on('recharge_update')
def handle_recharge_update(data):
    """Handle recharge status updates"""
    try:
        phone_number = data.get('phone_number')
        status = data.get('status')
        
        if phone_number and status:
            # Update request status
            recharge_manager.update_recharge_request(phone_number, status=status)
            
            # Emit update to all connected clients
            socketio.emit('recharge_update', {
                'phone_number': phone_number,
                'status': status
            })
            
            return {'success': True}
    except Exception as e:
        logger.error(f"Error handling recharge update: {str(e)}")
        return {'success': False, 'error': str(e)}
